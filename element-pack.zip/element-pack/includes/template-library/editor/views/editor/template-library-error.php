<?php
/**
 * templates loader view
 */
?>
<div class="elementor-library-error">
	<div class="elementor-library-error-message"><?php
		_e( 'Template couldn\'t be loaded. Please activate you license key before.', 'bdthemes-element-pack' );
	?></div>
	<div class="elementor-library-error-link"><?php

	?></div>
</div>