# Changelog

## 1.0.3
- FIX: Compatibility with Elementor 2.6.0

## 1.0.2
- FIX: Compatibility with Elementor 2.3.3

## 1.0.1
- FIX: Compatibility with Elementor 2.3.0

## 1.0.0

Initial release
