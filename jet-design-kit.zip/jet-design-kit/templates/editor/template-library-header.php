<?php
/**
 * Template Library Header Template
 */
?>
<div id="jet-template-library-header-tabs"></div>
<div id="jet-template-library-header-actions"></div>
<div id="jet-template-library-header-close-modal" class="elementor-template-library-header-item" title="<?php esc_html_e( 'Close', 'jet-design-kit' ); ?>">
	<i class="eicon-close" title="Close"></i>
</div>