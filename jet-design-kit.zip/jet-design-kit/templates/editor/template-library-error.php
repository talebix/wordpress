<?php
/**
 * templates loader view
 */
?>
<div class="elementor-library-error">
	<div class="elementor-library-error-message"><?php
		_e( 'Template couldn\'t be loaded.', 'jet-design-kit' );
	?></div>
</div>