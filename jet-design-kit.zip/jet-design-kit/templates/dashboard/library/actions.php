<?php
/**
 * Actions
 */
?>
<div class="jet-library-actions">
	<a href="<?php echo $this->sync_library_url(); ?>" class="cx-button cx-button-primary-style"><?php
		_e( 'Synchronize Templates Library', 'jet-design-kit' );
	?></a>
</div>
