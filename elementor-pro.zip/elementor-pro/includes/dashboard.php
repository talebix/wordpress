<?php
/**
 * Add RSS Feed to dashboard

 */
 function dashboard_iranelementor_wp() {
     global $wp_meta_boxes;
     // remove unnecessary widgets  
     // var_dump( $wp_meta_boxes['dashboard'] ); // use to get all the widget IDs  
     unset(  
          $wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins'],  
          $wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary'],  
          $wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']  
     );  
     // add dashboard widget  
     wp_add_dashboard_widget( 'dashboard_custom_feed', 'جدیدترین مقالات ایران المنتور', 'elementor_feed_output' ); //add new RSS feed output
}
function elementor_feed_output() { ?>
            <div style="margin-top: 10px;" class="rss-widget"> </div>
        
<?php
     wp_widget_rss_output(array(
          'url' => 'https://iranelementor.com/feed',
          'title' => 'ایران المنتور',
          'items' => 4,
          'show_summary' => 1,
          'show_author' => 0,
          'show_date' => 0
     ));
?>
		<p style ="border-top: 1px solid #eee; margin: 12px -12px 12px; padding:0px;>
		
		<div class="p-overview__footer" style="">
				<ul style="display: flex;list-style: none;margin: 0;padding: 0;">
					<li style="padding: 0 10px; margin: 0; border-right: 1px solid #ddd;" class="p-overview__faq"><a href="https://my.iranelementor.com/login" target="_blank">ارسال تیکت پشتیبانی <span class="screen-reader-text">new window</span><span aria-hidden="true" class="dashicons dashicons-external"></span></a></li>
				</ul>
	<?php	
}

add_action('wp_dashboard_setup', 'dashboard_iranelementor_wp');
